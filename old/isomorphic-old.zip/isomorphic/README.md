# Isomorphic - React Redux Admin Dashboard `Version 2.9.4`
