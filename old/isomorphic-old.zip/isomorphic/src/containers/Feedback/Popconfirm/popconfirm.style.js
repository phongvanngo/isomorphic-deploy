import styled from 'styled-components';

const PopconfirmStyleWrapper = styled.div`display: inline-block;`;

export default PopconfirmStyleWrapper;
