import styled from 'styled-components';

const styledModal = ComponentName => styled(ComponentName)`color: #0f0;`;

export { styledModal };
