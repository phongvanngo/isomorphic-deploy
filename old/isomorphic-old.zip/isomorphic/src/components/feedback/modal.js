import { Modal } from 'antd';

export default Modal;
