import { message } from 'antd';

export default message;
